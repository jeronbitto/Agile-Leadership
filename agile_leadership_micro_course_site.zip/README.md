
# Agile Leadership Micro-Course

This is a simple micro-course on Agile Leadership, designed to be hosted on GitHub Pages.

### How to Deploy on GitHub Pages
1. Clone the repository or upload all files to a new GitHub repository.
2. In the repository settings, go to the "GitHub Pages" section.
3. Set the source to the main branch and save.
4. Your course will be live at `https://yourusername.github.io/repository-name`.

### Course Contents
1. **Lesson 1**: Introduction to Agile Leadership Principles
2. **Lesson 2**: Running a Simple Retrospective
